# Series Temporais 1
## Aula de Econometria Avançada
Aula nº 2 com comandos básicos de gráficos e pacotes
