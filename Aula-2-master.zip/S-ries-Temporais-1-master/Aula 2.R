rep(10,5)  #repete o 10 cinco vezes
install.packages("pwt8") #instala o pacote de dados
